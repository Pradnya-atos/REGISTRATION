function validateForm() {
    let fname = document.forms["myForm"]["fname"].value;
    let Ename = document.forms["myForm"]["Ename"].value;
    let Nname = document.forms["myForm"]["Nname"].value;
    let ADDname = document.forms["myForm"]["ADDname"].value;
    let Pname = document.forms["myForm"]["Pname"].value;
   
   
   
   
    if (fname == "") {
      alert("Name must be filled out");
    
    }
    else if(Ename =="") {
        alert("email must be filled out");
    }else if(Nname =="") {
        alert("Phone Number must be filled out");
    }else if(ADDname =="") {
        alert("Address must be filled out");
    }else if(Pname =="") {
        alert("Password must be filled out");
        
    }else{
        alert("successfully registered.Thank you for registering in FoOdStOrE")
    }
  }



  